var service = 
  {
    rm   : { 'ap-chuncheon-1' : 'resourcemanager.ap-chuncheon-1.oci.oraclecloud.com',
                      'ap-seoul-1' : 'resourcemanager.ap-seoul-1.oraclecloud.com',
                      'us-ashburn-1' : 'resourcemanager.us-ashburn-1.oci.oraclecloud.com'}
  };

module.exports = {
    service: service
};
