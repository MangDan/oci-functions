var job = require( './rm/job.js' );

module.exports = {
    job: job
}